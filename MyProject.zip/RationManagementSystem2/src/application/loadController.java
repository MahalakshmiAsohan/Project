package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;

import java.sql.ResultSet;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;


public class loadController implements Initializable {
	@FXML
	private TableView<RationData> datatab;
	@FXML
	private TableColumn<RationData, String> itemid;
	@FXML
	private TableColumn<RationData, String> quantityid;
	@FXML
	private TableColumn<RationData, String> statusid;
	@FXML
	private ObservableList<RationData> data;
	@FXML
	private Button loadid;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		loadData(null);
	}
	public void loadData(ActionEvent event)
	{
		try {
					
			Connection con = SqliteConnection.connector();
			this.data=FXCollections.observableArrayList(); 
			
			ResultSet rs = con.createStatement().executeQuery("select * from Items");
			
			while(rs.next()) {
				System.out.println(rs.getString(1)+rs.getString(2)+rs.getString(3));	
				this.data.add(new RationData(rs.getString(1), rs.getString(2), rs.getString(3)));
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		this.itemid.setCellValueFactory(new PropertyValueFactory<RationData,String>("itemname"));
		this.quantityid.setCellValueFactory(new PropertyValueFactory<RationData, String>("quantity"));
		this.statusid.setCellValueFactory(new PropertyValueFactory<RationData, String>("status"));
		
		this.datatab.setItems(null);
		this.datatab.setItems(this.data);
	}

	
public void AdminopenPage(ActionEvent event) throws IOException

{

Stage primaryStage=new Stage();

Parent root = (Parent)FXMLLoader.load(getClass().getResource("AdminLogin.fxml"));

Scene scene = new Scene(root);

scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

primaryStage.setScene(scene);

primaryStage.show();

}
}
	/*
	public void CheckPage(ActionEvent event) throws IOException
	{
		Stage primaryStage =new Stage();
		Parent root = (Parent)FXMLLoader.load(getClass().getResource("load.fxml"));
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
		}
	
	public void  CheckAvailability(ActionEvent event) {
		
		System.out.println("Check Items");
		try
		{
			Connection con=SqliteConnection.connector();
			//PreparedStatement prs=con.prepareStatement("select * from Items where ItemName=="RICE" AND Quantity<=5 OR ItemName=="SUGAR" AND Quantity<=7 OR ItemName=="DHAL" AND Quantity<=2 THEN );
			
			PreparedStatement prs=con.prepareStatement("Select ItemName = ? AND Quantity = ? from Items where Status = 'Available'"); 	
			prs.setString(1,  this.cproduct.getText());
			prs.setString(2,  this.cnum.getText());
			cavailable.setText("Status");
					
			
					
			
			if(cnum!=null) {
				cavailable.setText("unAvailable");
				//System.out.println("Available");
			}
			else {
				cavailable.setText("Not Available");
				//System.out.println("Not Available");
			}
			//prs.executeUpdate();
			prs.executeQuery();
			con.close();
		}
	catch(Exception e)
		{
		e.printStackTrace();
		}
		//loadData(event);
	}
}

	/*public void clearData(ActionEvent event) {
		
		//System.out.println("Data = " + this.usernameTxt.getText());
		try {
			usernameTxt.setText("");
			passwordTxt.setText("");
		} catch(Exception e) {
			e.printStackTrace();
		}
		loadData(event);
	}
	
	}
	
	 {
	
}*/
	
