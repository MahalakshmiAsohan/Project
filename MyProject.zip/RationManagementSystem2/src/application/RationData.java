package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class RationData {

		
	final StringProperty Itemname;
	final StringProperty Quantity;
	final StringProperty Status;	
	
	public RationData(String Itemname, String Quantity, String Status) {
		this.Itemname = new SimpleStringProperty(Itemname);
		this.Quantity = new SimpleStringProperty(Quantity);
		this.Status = new SimpleStringProperty(Status);
	}

	public final StringProperty ItemnameProperty() {
		return this.Itemname;
	}
	

	public final String getItemname() {
		return this.ItemnameProperty().get();
	}
	

	public final void setItemname(final String Itemname) {
		this.ItemnameProperty().set(Itemname);
	}
	

	public final StringProperty QuantityProperty() {
		return this.Quantity;
	}
	

	public final String getQuantity() {
		return this.QuantityProperty().get();
	}
	

	public final void setQuantity(final String Quantity) {
		this.QuantityProperty().set(Quantity);
	}
	

	public final StringProperty StatusProperty() {
		return this.Status;
	}
	

	public final String getStatus() {
		return this.StatusProperty().get();
	}
	

	public final void setStatus(final String Status) {
		this.StatusProperty().set(Status);
	}
	
	
	

}

