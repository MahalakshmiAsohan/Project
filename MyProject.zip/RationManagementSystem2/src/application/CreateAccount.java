package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class CreateAccount implements Initializable {
	//Check Availability Page
	@FXML
	private TextField ctext;
	@FXML
	private PasswordField cpassword;
	@FXML
	private PasswordField cpassword1;
	@FXML
	private Button csubmit;
	@FXML
	private Button cmain;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}
	
	
	public void CreateAccount(ActionEvent event) throws IOException
	{
		System.out.println("Account Creation");
		try
		{
			Connection con=SqliteConnection.connector();
			PreparedStatement prs=con.prepareStatement("insert into Login(username,password)values(?,?)");
			prs.setString(1, this.ctext.getText());
			prs.setString(2, this.cpassword.getText());
			prs.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		//loadData(event);
	}
	public void HomePage(ActionEvent event) throws IOException

	{

	Stage primaryStage=new Stage();

	Parent root = (Parent)FXMLLoader.load(getClass().getResource("Sample.fxml"));

	Scene scene = new Scene(root);

	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

	primaryStage.setScene(scene);

	primaryStage.show();

	}		
}
	
