package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;



import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MenuSampleController implements Initializable {
	//MenuPage
	@FXML
	private Label clabel;
	@FXML
	private Button cadd;
	@FXML
	private Button cupdate;
	@FXML
	private Button cdelete;
	@FXML
	private Button ccheck;
	
	@FXML
	private TextField cid;
	@FXML
	private TextField ctext;
	@FXML
	private TextField caddress;
	@FXML
	private TextField cphone;
	@FXML
	private TextField cration;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}
	public void AdminOpenPage(ActionEvent event) throws IOException

	{

	Stage primaryStage=new Stage();

	Parent root = (Parent)FXMLLoader.load(getClass().getResource("CreateAccount.fxml"));

	Scene scene = new Scene(root);

	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

	primaryStage.setScene(scene);

	primaryStage.show();

	}
	
	public void Insert(ActionEvent event)
	{
		System.out.println("ADD ed");
		try
		{
			Connection con=SqliteConnection.connector();
			PreparedStatement prs=con.prepareStatement("insert into Customers(id,username,address,phoneno,rationid)values(?,?,?,?,?)");
			prs.setString(1, this.cid.getText());
			prs.setString(2, this.ctext.getText());
			prs.setString(3, this.caddress.getText());
			prs.setString(4, this.cphone.getText());
			prs.setString(5, this.cration.getText());
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Information Dialog");
			alert.setHeaderText(null);
			alert.setContentText("Customer has been added");
			alert.showAndWait();
			prs.executeUpdate();
			con.close();
		}
	catch(Exception e)
		{
		e.printStackTrace();
		}
		//loadData(event);
	}

	public void updateData(ActionEvent event) {
		System.out.println("Data = " + this.ctext.getText());
		try {
			Connection con = SqliteConnection.connector();
			PreparedStatement prs = con.prepareStatement("update Customers set address = ? where rationid = ?");
			prs.setString(1, this.caddress.getText());
			prs.setString(2, this.cration.getText());
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Information Dialog");
			alert.setHeaderText(null);
			alert.setContentText("Data has been Updated");
			alert.showAndWait();
			prs.executeUpdate();
			con.close();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		//loadData(event);
	}

	public void deleteData(ActionEvent event) {
		System.out.println("Data = " + this.ctext.getText());
		try {
			Connection con = SqliteConnection.connector();
			PreparedStatement prs = con.prepareStatement("delete from Customers where username = ?");
			prs.setString(1, this.ctext.getText());
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Information Dialog");
			alert.setHeaderText(null);
			alert.setContentText("Data has been deleted");
			alert.showAndWait();
			prs.executeUpdate();
			con.close();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		//loadData(event);
	}
}
	/*public void CheckPage(ActionEvent event) throws IOException
	{
		Stage primaryStage =new Stage();
		Parent root = (Parent)FXMLLoader.load(getClass().getResource("load.fxml"));
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
		}
	
}*/
	/*public void clearData(ActionEvent event) {
		
		//System.out.println("Data = " + this.usernameTxt.getText());
		try {
			usernameTxt.setText("");
			passwordTxt.setText("");
		} catch(Exception e) {
			e.printStackTrace();
		}
		loadData(event);
	}
	
	}
	
	 {
	
}*/
	
