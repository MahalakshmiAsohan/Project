package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CheckAvailabilityController implements Initializable {
	//Check Availability Page
	@FXML
	private Label cname;
	@FXML
	private Label cquantity;
	@FXML
	private Label cavailable;
	
	@FXML
	private TextField cproduct;
	@FXML
	private TextField cnum;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}
	
	
	public void CheckPage(ActionEvent event) throws IOException
	{
		Stage primaryStage =new Stage();
		Parent root = (Parent)FXMLLoader.load(getClass().getResource("CheckAvailability.fxml"));
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
		}
	
	public void  CheckAvailability(ActionEvent event) {
		
		System.out.println("Check Items");
		try
		{
			Connection con=SqliteConnection.connector();
			//PreparedStatement prs=con.prepareStatement("select * from Items where ItemName=="RICE" AND Quantity<=5 OR ItemName=="SUGAR" AND Quantity<=7 OR ItemName=="DHAL" AND Quantity<=2 THEN );
			
			PreparedStatement prs=con.prepareStatement("Select ItemName = ? AND Quantity = ? from Items where Status = 'Available'"); 	
			prs.setString(1,  this.cproduct.getText());
			prs.setString(2,  this.cnum.getText());
			cavailable.setText("Status");
					
			
					
			
			if(cnum!=null) {
				cavailable.setText("unAvailable");
				//System.out.println("Available");
			}
			else {
				cavailable.setText("Not Available");
				//System.out.println("Not Available");
			}
			//prs.executeUpdate();
			prs.executeQuery();
			con.close();
		}
	catch(Exception e)
		{
		e.printStackTrace();
		}
		//loadData(event);
	}
}

	/*public void clearData(ActionEvent event) {
		
		//System.out.println("Data = " + this.usernameTxt.getText());
		try {
			usernameTxt.setText("");
			passwordTxt.setText("");
		} catch(Exception e) {
			e.printStackTrace();
		}
		loadData(event);
	}
	
	}
	
	 {
	
}*/
	
