package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CanteenLogin {
	Connection connection;

	public CanteenLogin() {
		connection = SqliteConnection.connector();
		if (connection == null)
			System.exit(1);
	}

public boolean isDbCOnnected()
{
	try {
		return !connection.isClosed();

	}
catch(Exception e)
	{
	return false;
	}
}

public boolean isValidLogin(String username,String password) throws SQLException
{
	
PreparedStatement pstmt=null;
	 
	 	
	//PreparedStatement pstmt=null;
   


ResultSet rs = null;
String query="SELECT * FROM Login WHERE username=? AND password=?";
	try {
		pstmt=connection.prepareStatement(query);
		pstmt.setString(1,username);
		pstmt.setString(2,password);
		rs=pstmt.executeQuery();
		if(rs.next())
		{
			return true;
		}
		return false;
	}
	catch (Exception e)
	{
		e.printStackTrace();
		return false;
	}
	finally {
		rs.close();
	}
}
}