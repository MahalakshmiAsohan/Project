package application;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import  javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
	public class AdminSampleController implements Initializable {
		AdminLogin loginmodel=new AdminLogin();

		@FXML
		private Label clabel ;

		@FXML
		private Button clogin;
		@FXML
		private Button clogin1;
		
		@FXML
		private Button ccreate;

		@FXML
		private TextField ctext;

		@FXML
		private PasswordField cpassword;



		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {

		if(loginmodel.isDbCOnnected())

			clabel.setText("DB Connected....");

		else

			clabel.setText("DB COnnection Failed....");


		}

		public void loginCheck(ActionEvent event)

		{

			System.out.println(ctext.getText()+ cpassword.getText());

			try {

				if(loginmodel.isValidLogin(ctext.getText() , cpassword.getText()))

				{

					clabel.setText("Valid Username and password");

					Stage stage=(Stage)this.cpassword.getScene().getWindow();

		stage.close();

		openPage(event);

		}

		else

		{

		clabel.setText("InValid Username and password");

		}


		}

		catch(Exception e)

		{

		clabel.setText("InValid Username and password");

		}

		}
		
private void openPage(ActionEvent event) {
	// TODO Auto-generated method stub
	
}
	

		
		
		
	}


