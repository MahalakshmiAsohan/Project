package application;

import java.sql.Connection;
import java.sql.DriverManager;

public class SqliteConnection {

	public static Connection connector() {
		try {
			Connection con = DriverManager.getConnection("jdbc:sqlite:Ration.db");
			return con;
		}
		catch(Exception e) {
			return null;
		}
	}
	
}
